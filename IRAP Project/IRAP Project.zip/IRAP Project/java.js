/*
var loggedIn = false;

function authenticate() {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  loggedIn = login(username, password);
  status();
}

function login(username) {
  var storedUsername = "ucc";

  return username == storedUsername;
}
function login(password) {
  var storedPassword = "ucc123";

  return password == storedPassword;
}
function status() {
  if (loggedIn) {
    window.location.href = "google.com";
  } else {
    console.log("Incorrect Username or Password");
  }
}
*/
var attemp = 3;
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if (username == "UcLogin" && password == "UC123@"{
  alert ("Login Successfully");
window.location = "success.html"; 
return false;
}
else{
  attempt --;
  alert("You have left"+attempt+ "")ttempt;
};
  if (attempt == 0){
    document.getElementByield("username").disabled = true;
    document.getElementById("password").disabled = true;
    document.getElementById("submit").disabled = true;
    }a
}